import React, { useState, useEffect } from 'react';
import Styles from './Interaction.module.css';
import axios from 'axios';

const Interaction = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  const [data, setData] = useState([]);

  const handleAccordionClick = (index) => {
    setActiveIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  const fetchAccordionData = () => {
    axios
      .get('https://mocki.io/v1/40059489-6a19-4ca7-a41c-1c5c920e312c')
      .then((res) => {
        setData(res.data.spans);
        console.log(res);
      })
      .catch((err) => {
        console.log('err', err);
      });
  };

  useEffect(() => {
    fetchAccordionData();
  }, []);

  return (
    <section className={Styles.parentGrid}>
      <div className='d-flex justify-content-center'>
        <div className={Styles.accordionContainer}>
          {data.length > 0 ? (
            data.map((item, index) => (
              <div
                key={index}
                className={`accordion-item ${index === activeIndex ? 'active' : ''}`}
              >
                <div
                  className={Styles.accordionTitle}
                  onClick={() => handleAccordionClick(index)}
                >
                  {item.destination}
                </div>
                {index === activeIndex && (
                  <div className={Styles.accordionContent}>
                    <p>Span ID: {item.span_id}</p>
                    <p>Trace ID: {item.trace_id}</p>
                    <p>Request Method: {item.req_info.req_method}</p>
                    <p>Request Path: {item.req_info.req_path}</p>
                    <p>Latency: {item.req_info.latency}</p>
                    {/* Add other information from the response as needed */}
                  </div>
                )}
              </div>
            ))
          ) : (
            <p>Loading...</p>
          )}
        </div>
      </div>
    </section>
  );
};

export default Interaction;
