import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Interaction from "./Component/index"
function App() {

  return (
    <>
   <Interaction />
 
    </>
  )
}

export default App
